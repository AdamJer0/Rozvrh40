package com.company;

import java.util.ArrayList;

public class Rozvrh {
    private int score = 0;
    private Hodina hodina;
    private ArrayList<Hodina> rozvrh = new ArrayList<Hodina>();

    public int getScore() {
        return score;
    }
    public void setScore(int score) {
        this.score = score;
    }

    public ArrayList<Hodina> vytvotRozvrh(){



        for (int i = 0; i < 40; i++){
            rozvrh.add(hodina = new Hodina(getRandomNumber(), poradoveCisloHodinyDne, boolean delena, Ucebna ucebna, int poradoveCisloDneVtydnu, Ucitel zvolenyUcitel, Predmet predmet), Ucebna ucebna, int poradoveCisloDneVtydnu, Ucitel zvolenyUcitel, Predmet predmet)));

            this.getScore();
            System.out.println("Skore tohoto rozvrhu je: " + score);
        }
        return rozvrh;
    }

    public static double getRandomNumber(){
        double x = Math.random();
        return x;
    }










}
