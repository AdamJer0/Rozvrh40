package com.company;

public class Ucebna {

    private String jmenoUcebny;
    private boolean obsazena;

    public Ucebna(String jmenoMistnosti) {
        this.jmenoUcebny = jmenoMistnosti;
    }
    public String getJmenoUcebny() {
        return jmenoUcebny;
    }
    public void setJmenoUcebny(String jmenoUcebny) {
        this.jmenoUcebny = jmenoUcebny;
    }







}
